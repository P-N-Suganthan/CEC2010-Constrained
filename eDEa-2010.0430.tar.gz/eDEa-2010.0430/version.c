#include <stdio.h>
#include "eOPT.h"

void version()
{
	printf("eDEa %s, extracted from eOPT version %s\n",
		VERSION, LAST_UPDATE);
	printf("Copyright (c) Tetsuyuki Takahama and Setsuko Sakai, 2010\n");
}
