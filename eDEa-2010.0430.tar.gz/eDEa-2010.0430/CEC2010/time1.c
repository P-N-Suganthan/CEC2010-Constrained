#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "lib/rand.h"
#define MAINPROGRAM
#include "eOPT.h"
#include "constraints.h"

#include <windows.h>
#include <process.h>
typedef void (WINAPI * PPROC) (double *, double *, double *, double *, int, int, int, int);
#define LIBHANDLE HANDLE
#define GetProcedure GetProcAddress
#define CloseDynalink FreeLibrary
#define MAXDIM	100

#include <sys/time.h>
double gettimeofday_sec()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + (double)tv.tv_usec*1e-6;
}

void main(int argc, char *argv[])
{
	int p, i, j, k;
	double f, x[MAXDIM], c[MAXDIM];
	double time=0, time1, time2;

	if(argc!=2) {
		printf("%s dim\n", argv[0]);
		exit(1);
	}
	Length=atoi(argv[1]);
	for(j=0; j<Length; j++)
		x[j]=-2.0+Rand()*4.0;
	for(Problem=1; Problem<=18; Problem++) {
		Upper=Lower=0;
		InitProblem();
		printf("%s of %d vars, %d ineqs, %d eqs: ",
			Defs->name, Length, Inequalities, Equalities);
		time1=gettimeofday_sec();
		for(i=0; i<10000; i++) {
			EvaluateFC(x, &f, c);
		}
		time2=gettimeofday_sec();
		time+=(time2-time1);
		printf("%f\n", time2-time1);
	}
	printf("%f\n", time);
	ExitProblem();
}
