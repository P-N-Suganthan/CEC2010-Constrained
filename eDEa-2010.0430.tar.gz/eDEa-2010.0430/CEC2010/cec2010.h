/* dll.c */
void InitDLL(void);
void ExitDLL(void);
void EvaluateFC(VARIABLE x[], VALUE *fp, VALUE c[]);

/* cec2010.c */
void InformationCEC(Individual best, int isfirst, int updated);
