void EvaluateNabla(VARIABLE x[], int n, VALUE c[], VALUE nabla[][n]);
