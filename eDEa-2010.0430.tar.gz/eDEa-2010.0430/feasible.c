#include <stdio.h>
#include <stdlib.h>
#define MAINPROGRAM
#include "eOPT.h"
#include "constraints.h"

void Updated() {}
void InitOptimizer() {}
void InitGradientMutation() {}

main(int argc, char **argv)
{
	Parameters(argc, argv);

	int j;
	VALUE C[Constraints];
	VARIABLE x[Length];
	VALUE f, error, violation;

	for(j=0; j<Length; j++) {
		printf("x[%d]=", j+1);
		scanf("%lf", &x[j]);
	}
	EvaluateFC(x, &f, C);
	ConstraintViolation(x, C, &error, &violation);
	printf("f=%.8g, error=%.8g, violation=%.8g\n", f, error, violation);
	for(j=0; j<Constraints; j++)
		printf("C[%d]=%.8g\n", j+1, C[j]);
}
